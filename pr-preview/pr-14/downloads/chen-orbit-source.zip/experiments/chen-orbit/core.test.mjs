import test from 'node:test';
import assert from 'node:assert/strict';
import {parameters,defaults,derivative,rk4,buildAttractor,cameraAt,readSettings,settingsQuery,wrap,switchCameraMotion} from './core.mjs';
test('reference equations and coefficients are exact',()=>{assert.deepEqual(parameters,{a:36,b:3,c:20});assert.deepEqual(derivative([2,3,4]),[36,52,-6]);assert.deepEqual(derivative([0,0,0]),[0,0,0]);});
test('RK4 agrees with two half steps on a short interval',()=>{const p=[3,4,20],a=rk4(p,.002),b=rk4(rk4(p,.001),.001);for(let i=0;i<3;i++)assert.ok(Math.abs(a[i]-b[i])<1e-7);});
test('deterministic trajectory is finite, bounded, occupies both wings and has real depth',()=>{const a=buildAttractor({count:12000}),b=buildAttractor({count:12000});assert.deepEqual(a.data,b.data);assert.ok(a.data.every(Number.isFinite));assert.ok(a.bounds.min[0]<-1&&a.bounds.max[0]>1);assert.ok(a.bounds.max[2]-a.bounds.min[2]>.3);assert.ok(a.bounds.max.every(n=>Math.abs(n)<2));assert.ok(a.bounds.min.every(n=>Math.abs(n)<2));assert.equal(a.data[3],0);assert.equal(a.data.at(-1),1);});
test('camera loop returns exactly, with matching endpoint velocity',()=>{assert.deepEqual(cameraAt(defaults,0),cameraAt(defaults,1));const e=1e-5,a=cameraAt(defaults,e),b=cameraAt(defaults,1-e),s=cameraAt(defaults,0);assert.ok(Math.abs((a.elevation-s.elevation)/e-(s.elevation-b.elevation)/e)<1e-7);assert.deepEqual(cameraAt({...defaults,motion:'still'},.2),cameraAt({...defaults,motion:'still'},.7));});
test('scene links preserve all controls and sanitize untrusted numbers',()=>{const p={...defaults,azimuth:25,elevation:-8,zoom:1.2,palette:'glacier'},r=readSettings(settingsQuery(p,.25));assert.deepEqual(r.parameters,p);assert.equal(r.phase,.25);assert.equal(r.paused,true);const bad=readSettings('?zoom=Infinity&duration=1&palette=bad&elevation=999&phase=no');assert.equal(bad.parameters.zoom,1);assert.equal(bad.parameters.duration,8);assert.equal(bad.parameters.elevation,180);assert.equal(bad.parameters.palette,'ember');assert.equal(bad.phase,0);});
test('reject invalid integration sizes and steps',()=>{for(const opts of [{count:1},{count:NaN},{dt:0},{dt:1},{burn:-1}])assert.throws(()=>buildAttractor(opts),RangeError);});

test('camera elevation remains smooth at both slider extremes',()=>{for(const elevation of [-80,-78,78,80]){const p={...defaults,elevation},e=1e-5,a=cameraAt(p,e),b=cameraAt(p,1-e),s=cameraAt(p,0);assert.ok(Math.abs((a.elevation-s.elevation)/e-(s.elevation-b.elevation)/e)<1e-7);for(let phase=0;phase<1;phase+=.01)assert.ok(Math.abs(cameraAt(p,phase).elevation)<=80*Math.PI/180+1e-12);}});

test('resuming orbit can preserve both the camera pose and illumination phase',()=>{const phase=.37,p={...defaults,motion:'still',azimuth:31,elevation:23},before=cameraAt(p,phase),after=cameraAt({...p,motion:'orbit',cameraOffset:wrap(-phase)},phase);assert.deepEqual(after,before);});

// The basis vectors, rather than raw Euler angles, encode the visible frame.
function cameraFrame(c){const a=c.azimuth,e=c.elevation;return [Math.cos(a),0,Math.sin(a),Math.sin(a)*Math.sin(e),Math.cos(e),-Math.cos(a)*Math.sin(e),-Math.sin(a)*Math.cos(e),Math.sin(e),Math.cos(a)*Math.cos(e)];}
function closeFrame(a,b,tolerance=1e-10){cameraFrame(a).forEach((v,i)=>assert.ok(Math.abs(v-cameraFrame(b)[i])<tolerance));}
test('vertical camera crosses directly above and below without a pole discontinuity',()=>{
 const p={...defaults,motion:'vertical',azimuth:29,elevation:0};
 assert.deepEqual(cameraAt(p,0),cameraAt(p,1));
 assert.ok(Math.abs(cameraFrame(cameraAt(p,.25))[7]-1)<1e-12);
 assert.ok(Math.abs(cameraFrame(cameraAt(p,.75))[7]+1)<1e-12);
 for(const phase of [.25,.5,.75,1])closeFrame(cameraAt(p,phase-1e-7),cameraAt(p,phase+1e-7),2e-6);
 const e=1e-5,a=cameraFrame(cameraAt(p,e)),b=cameraFrame(cameraAt(p,1-e)),s=cameraFrame(cameraAt(p,0));
 for(let i=0;i<a.length;i++)assert.ok(Math.abs((a[i]-s[i])/e-(s[i]-b[i])/e)<.001);
});
test('all camera path transitions preserve full orientation and linked settings at any phase',()=>{
 for(const from of ['orbit','vertical','still'])for(const to of ['orbit','vertical','still'])for(const phase of [0,.2,.25,.5,.75,.999]){
  const p={...defaults,motion:from,azimuth:43,elevation:17,cameraOffset:.13},next=switchCameraMotion(p,to,phase);
  closeFrame(cameraAt(p,phase),cameraAt(next,phase));
  const replay=readSettings(settingsQuery(next,phase));for(const key of Object.keys(next)){if(typeof next[key]==='number')assert.ok(Math.abs(replay.parameters[key]-next[key])<1e-12);else assert.equal(replay.parameters[key],next[key]);}assert.ok(Math.abs(replay.phase-wrap(phase))<1e-12);closeFrame(cameraAt(replay.parameters,replay.phase),cameraAt(next,phase));
 }
 assert.throws(()=>switchCameraMotion(defaults,'invalid',0),RangeError);
});
test('held inverted poses and both new tilt extremes survive scene links',()=>{
 for(const elevation of [-180,-125,100,180]){const p={...defaults,motion:'still',elevation};assert.deepEqual(readSettings(settingsQuery(p,.6)).parameters,p);closeFrame(cameraAt(p,.1),cameraAt(p,.9));}
 assert.equal(readSettings('?motion=vertical').parameters.motion,'vertical');
});
