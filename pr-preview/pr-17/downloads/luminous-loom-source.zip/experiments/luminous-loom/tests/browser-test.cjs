// Run from the repository root. Requires Playwright Chromium and ffmpeg/ffprobe.
const assert=require('node:assert/strict');
const fs=require('node:fs/promises'),path=require('node:path'),http=require('node:http');
const {execFileSync}=require('node:child_process');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const root=path.resolve(__dirname,'../../..'),output=path.resolve(process.env.QA_OUTPUT||'/tmp/luminous-loom-qa');
const types={'.html':'text/html','.mjs':'application/javascript','.js':'application/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml'};
const server=http.createServer(async(req,res)=>{try{let name=decodeURIComponent(new URL(req.url,'http://local').pathname);if(name.endsWith('/'))name+='index.html';const file=path.resolve(root,'.'+name);if(!file.startsWith(root+path.sep))throw Error('Invalid path');res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');res.end(await fs.readFile(file));}catch{res.writeHead(404);res.end('Not found');}});
let browser,page;const errors=[],results=[],evidence={};
const log=m=>{results.push(m);console.log('PASS · '+m);};
const deadline=setTimeout(()=>{console.error('Loom QA exceeded 20 minutes');process.exit(1);},1200000);
const settle=p=>p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
async function range(p,id,value){await p.locator('#'+id).evaluate((el,v)=>{el.value=String(v);el.dispatchEvent(new Event('input',{bubbles:true}));},value);await settle(p);}
async function hash(p){await settle(p);return p.locator('#scene').evaluate(c=>c.toDataURL());}
const snapshot=(p,name)=>p.screenshot({path:path.join(output,name+'.png')});
async function assertScene(p,label,clean=false){
 await settle(p);
 const info=await p.locator('#scene').evaluate(c=>{
  const r=c.getBoundingClientRect(),data=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let colored=0;
  for(let i=0;i<data.length;i+=4){const hi=Math.max(data[i],data[i+1],data[i+2]),lo=Math.min(data[i],data[i+1],data[i+2]);if(hi>50&&hi-lo>25)colored++;}
  return {width:c.width,height:c.height,cssWidth:r.width,cssHeight:r.height,x:r.x,y:r.y,right:r.right,bottom:r.bottom,viewport:[innerWidth,innerHeight],dpr:Math.min(devicePixelRatio||1,2),colored};
 });
 assert.ok(info.colored>20,label+': missing colored drawing '+JSON.stringify(info));
 assert.equal(info.width,Math.round(info.cssWidth*info.dpr),label+': canvas width not resized');
 assert.equal(info.height,Math.round(info.cssHeight*info.dpr),label+': canvas height not resized');
 assert.ok(info.cssWidth>0&&info.cssHeight>0&&info.x>=-1&&info.right<=info.viewport[0]+1,label+': canvas exceeds width');
 if(clean){assert.ok(Math.abs(info.cssWidth-info.viewport[0])<=1&&Math.abs(info.cssHeight-info.viewport[1])<=1,label+': clean canvas does not fill viewport');assert.ok(info.y>=-1&&info.bottom<=info.viewport[1]+1,label+': clean canvas outside viewport');}
 evidence[label]=info;
}

function probe(file){return JSON.parse(execFileSync('ffprobe',['-v','error','-select_streams','v:0','-count_frames','-show_entries','stream=codec_name,width,height,r_frame_rate,nb_read_frames,duration','-of','json',file],{encoding:'utf8',timeout:60000})).streams[0];}
(async()=>{
 await fs.mkdir(output,{recursive:true});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const base=`http://127.0.0.1:${server.address().port}`,url=base+'/experiments/luminous-loom/';
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||undefined,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const context=await browser.newContext({viewport:{width:1280,height:900},deviceScaleFactor:1,reducedMotion:'reduce',acceptDownloads:true});
 context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
 page=await context.newPage();page.setDefaultTimeout(30000);
 await page.goto(url+'?phase=0&fibers=16&samples=128');await page.locator('#fibers').waitFor();
 assert.equal(await page.locator('#play').textContent(),'Play');
 const still=await hash(page);await page.waitForTimeout(150);assert.equal(await hash(page),still);
 await range(page,'phase',.173);const replay=await hash(page);await range(page,'phase',.429);assert.notEqual(await hash(page),replay);await range(page,'phase',.173);assert.equal(await hash(page),replay);
 await page.locator('#play').click();await page.waitForFunction(()=>Number(document.querySelector('#phase').value)>.174);await page.locator('#play').click();const paused=await hash(page);await page.waitForTimeout(150);assert.equal(await hash(page),paused);
 await page.locator('#reset').click();await settle(page);assert.equal(Number(await page.locator('#phase').inputValue()),0);
 await page.locator('#hide').click();assert.equal(await page.locator('aside').isVisible(),false);await assertScene(page,'desktop-clean',true);await snapshot(page,'desktop-hidden');await page.locator('#show').click();assert.equal(await page.locator('aside').isVisible(),true);await assertScene(page,'desktop-restored');
 log('Paused URL, exact phase replay, play/pause, reset and desktop hide/show');
 for(const [preset,knot,fibers,samples] of [['cinquefoil','T(2,5)',112,640],['orbital','T(3,4)',144,640],['stress','T(2,3)',384,1536],['ribbon','T(2,3)',96,640]]){await page.locator('#preset').selectOption(preset);await settle(page);assert.equal(await page.locator('#knot').textContent(),knot);assert.equal(Number(await page.locator('#fibers').inputValue()),fibers);assert.equal(Number(await page.locator('#samples').inputValue()),samples);await snapshot(page,'preset-'+preset);}
 for(const [id,value] of [['fibers',24],['samples',192],['spread',.8],['width',1.5],['opacity',.8],['zoom',.9],['duration',4]]){await range(page,id,value);assert.equal(Number(await page.locator('#'+id).inputValue()),value);assert.equal(Number(await page.locator('#'+id+'Value').evaluate(el=>el.value)),value);}
 for(const palette of ['ember','glacier','aurora']){const before=await hash(page);await page.locator('#palette').selectOption(palette);assert.notEqual(await hash(page),before);}
 const glow=await hash(page);await page.locator('#glow').uncheck();assert.notEqual(await hash(page),glow);await page.locator('#glow').check();
 await page.locator('details').filter({has:page.locator('#renderer')}).evaluate(el=>el.open=true);
 for(const renderer of ['path2d','merged','direct']){await page.locator('#renderer').selectOption(renderer);await settle(page);assert.equal(await page.locator('#renderer').inputValue(),renderer);}
 await snapshot(page,'desktop');log('Every preset, slider, palette, glow toggle and renderer control');
 // Real Canvas pixels from the same shared geometry/painter, independently of UI.
 evidence.pixels=await page.evaluate(async()=>{
  const {normalize,createGeometry,geometryAt}=await import('./core.mjs');const {preparePaths,paint}=await import('./renderer.mjs');
  const results=[];
  for(const scene of [{fibers:24,samples:192},{fibers:96,samples:640,p:3,q:5}])for(const phase of [0,.173,.5]){
   const p=normalize(scene),w=createGeometry(p),data=geometryAt(w,phase),images={};
   for(const mode of ['direct','path2d','merged']){const c=document.createElement('canvas');c.width=c.height=360;paint(c,data,p,preparePaths(data,p,mode),mode);images[mode]=c.getContext('2d').getImageData(0,0,360,360).data;}
   const delta=(a,b)=>{let max=0,sum=0,over2=0;for(let i=0;i<a.length;i+=4){let pixelMax=0;for(let c=0;c<3;c++){const d=Math.abs(a[i+c]-b[i+c]);max=Math.max(max,d);sum+=d;pixelMax=Math.max(pixelMax,d);}if(pixelMax>2)over2++;}return {max,mean:sum/(a.length/4*3),fractionOver2:over2/(a.length/4)};};
   results.push({scene,phase,path2d:delta(images.direct,images.path2d),merged:delta(images.direct,images.merged)});
  }
  return results;
 });
 for(const row of evidence.pixels){assert.ok(row.path2d.max<=32,JSON.stringify(row));assert.ok(row.path2d.mean<=.05,JSON.stringify(row));assert.ok(row.path2d.fractionOver2<=.001,JSON.stringify(row));assert.ok(Number.isFinite(row.merged.mean));}
 assert.ok(evidence.pixels.some(row=>row.merged.mean>0),'Merged compositing difference must be measured');
 console.log('PIXEL_DELTAS '+JSON.stringify(evidence.pixels));log('Fresh Path2D matches direct within strict raster tolerance; merged overlap error quantified');
 await page.goto(url);await page.locator('#fibers').waitFor();assert.equal(await page.locator('#play').textContent(),'Play');const reduced=await hash(page);await page.waitForTimeout(150);assert.equal(await hash(page),reduced);log('Reduced-motion default is paused without phase query');
 await page.goto(url+'?phase=0&fibers=8&samples=128&duration=4');await page.locator('#fibers').waitFor();
 await page.locator('details').filter({has:page.locator('#exportSize')}).evaluate(el=>el.open=true);
 await page.locator('#exportSize').selectOption('720');await page.locator('#exportFps').selectOption('30');
 await page.locator('details').filter({has:page.locator('#benchmark')}).evaluate(el=>el.open=true);
 // Exercise the real UI benchmark and downloaded report, not synthetic timers.
 await page.locator('#benchmark').click();assert.equal(await page.locator('#fibers').isEnabled(),false);
 await page.waitForFunction(()=>window.loomBenchmarkResult&&document.querySelector('#benchmark').textContent==='Compare matched frames',null,{timeout:180000});
 evidence.benchmark=await page.evaluate(()=>window.loomBenchmarkResult);
 assert.equal(evidence.benchmark.size,1080);assert.equal(evidence.benchmark.pass,true);assert.equal(evidence.benchmark.method.samples,9);
 for(const mode of ['direct','path2d','merged'])for(const stage of ['geometry','prepare','submit','readback','total']){const timing=evidence.benchmark.timings[mode][stage];assert.equal(timing.samples.length,9);assert.ok(timing.samples.every(n=>Number.isFinite(n)&&n>=0));assert.ok(timing.max>=timing.median&&timing.p95>=timing.min);}
 assert.equal(evidence.benchmark.pixels.length,8);assert.equal(await page.locator('#fibers').isEnabled(),true);
 const reportWait=page.waitForEvent('download',{predicate:d=>d.suggestedFilename().endsWith('.json')});await page.locator('#report').click();const reportDownload=await reportWait;await reportDownload.saveAs(path.join(output,'benchmark.json'));
 assert.deepEqual(JSON.parse(await fs.readFile(path.join(output,'benchmark.json'),'utf8')),evidence.benchmark);
 log('Real 1080-square benchmark measures all stages and three modes, checks pixels, and downloads matching report');
 const aborted=await page.evaluate(async()=>{const {runBenchmark}=await import('./benchmark.mjs');const c=new AbortController();c.abort();try{await runBenchmark({fibers:8,samples:128},{size:64,samples:3,warmup:0,signal:c.signal});return false;}catch(e){return e.name==='AbortError';}});assert.equal(aborted,true);
 // Cancel at the last pixel-phase yield, the prior race's boundary.
 const lateAbort=await page.evaluate(async()=>{const {runBenchmark}=await import('./benchmark.mjs');const c=new AbortController();try{await runBenchmark({fibers:8,samples:128},{size:64,samples:3,warmup:0,signal:c.signal,onProgress:m=>{if(m==='Comparing pixels · phase 0.731')c.abort();}});return false;}catch(e){return e.name==='AbortError';}});assert.equal(lateAbort,true);
 // Separate measured artistic/default and maximum stress workloads, not just
 // the light UI integration case. Timings are evidence, never speed assertions.
 evidence.workloads=await page.evaluate(async()=>{const {runBenchmark}=await import('./benchmark.mjs');const out=[];for(const [name,scene,size,samples] of [['default',{},1080,9],['stress',{fibers:384,samples:1536,width:.55,opacity:.38},1080,3],['default-2160',{},2160,5]])out.push({name,...await runBenchmark(scene,{size,samples,warmup:name==='stress'?1:2})});return out;});
 await fs.writeFile(path.join(output,'workloads.json'),JSON.stringify(evidence.workloads,null,2));
 for(const measured of evidence.workloads)assert.equal(measured.pass,true,'Same-path equivalence: '+measured.name);
 console.log('WORKLOAD_TOTALS '+JSON.stringify(evidence.workloads.map(r=>({name:r.name,size:r.size,timings:r.timings,pixels:r.pixels}))));log('Default, maximum stress and 2160-square workloads measured with raw stage samples and matched pixels');
 const pngWait=page.waitForEvent('download',{predicate:d=>d.suggestedFilename().endsWith('.png')});await page.locator('#png').click();const png=await pngWait,pngPath=path.join(output,'own-size.png');await png.saveAs(pngPath);const bytes=await fs.readFile(pngPath);assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.deepEqual([bytes.readUInt32BE(16),bytes.readUInt32BE(20)],[720,720]);log('PNG renders at selected 720 square output independent of preview');

 // Use the real browser PNG encoder; a fake directory handle captures the
 // browser's incremental writes without opening a native file picker in CI.
 await page.evaluate(()=>{
  window.__pngSequence={folder:null,files:new Map(),folders:[]};
  window.showDirectoryPicker=async()=>({
   async getDirectoryHandle(name,{create}){
    if(!create)throw Error('Must create an isolated child folder');
    const folder={name,files:new Map()};window.__pngSequence.folder=folder;
    window.__pngSequence.folders.push(folder);
    return {async getFileHandle(filename,{create:make}={}){
     if(!make)throw Error('Must create file');
     return {async createWritable(){
      let content;
      return {async write(value){content=value;},async close(){folder.files.set(filename,content);},async abort(){content=null;}};
     }};
    }};
   },
  });
 });
 await page.locator('#frames').click();
 assert.equal(await page.locator('#fibers').isEnabled(),false);
 await page.waitForFunction(()=>document.querySelector('#frames').textContent==='Export lossless PNG frames'&&/Saved 120 lossless PNG/.test(document.querySelector('#status').textContent),null,{timeout:480000});
 assert.equal(await page.locator('#fibers').isEnabled(),true);
 evidence.pngSequence=await page.evaluate(async()=>{
  const folder=window.__pngSequence.folder,files=folder.files,frames=[...files].filter(([name])=>name.endsWith('.png'));
  const first=files.get('frame-000000.png'),mid=files.get('frame-000060.png'),last=files.get('frame-000119.png');
  const {normalize,createGeometry,geometryAt}=await import('./core.mjs'),{preparePaths,paint}=await import('./renderer.mjs');
  const p=normalize({fibers:8,samples:128,duration:4}),workspace=createGeometry(p);
  async function identical(blob,phase){
   const img=await createImageBitmap(blob),actual=document.createElement('canvas'),reference=document.createElement('canvas');
   actual.width=actual.height=reference.width=reference.height=720;
   actual.getContext('2d').drawImage(img,0,0);img.close();
   const data=geometryAt(workspace,phase);paint(reference,data,p,preparePaths(data,p));
   const a=actual.getContext('2d').getImageData(0,0,720,720).data,b=reference.getContext('2d').getImageData(0,0,720,720).data;
   let differences=0;for(let i=0;i<a.length;i++)if(a[i]!==b[i])differences++;
   return differences;
  }
  return {name:folder.name,frames:frames.length,first:frames[0][0],last:frames.at(-1)[0],
   types:[first.type,mid.type,last.type],differentPixels:[await identical(first,0),await identical(mid,.5),await identical(last,119/120)],
   sidecar:files.get('scene-url.txt'),script:files.get('encode.sh')};
 });
 assert.equal(evidence.pngSequence.frames,120);assert.equal(evidence.pngSequence.first,'frame-000000.png');assert.equal(evidence.pngSequence.last,'frame-000119.png');
 assert.deepEqual(evidence.pngSequence.types,['image/png','image/png','image/png']);
 assert.deepEqual(evidence.pngSequence.differentPixels,[0,0,0],'Exported PNG pixels must exactly match direct rendering');
 assert.match(evidence.pngSequence.script,/ffmpeg -framerate 30/);
 assert.match(evidence.pngSequence.sidecar,/phase=0/);
 log('120 lossless browser PNG frames exactly match independent reference pixels and sidecars');
 await page.locator('#frames').click();
 await page.waitForFunction(()=>/Saving lossless PNG 10\//.test(document.querySelector('#status').textContent),null,{timeout:60000});
 await page.locator('#frames').click();
 await page.waitForFunction(()=>document.querySelector('#frames').textContent==='Export lossless PNG frames'&&/PNG export canceled/.test(document.querySelector('#status').textContent),null,{timeout:60000});
 evidence.pngCancellation=await page.evaluate(()=>{const files=window.__pngSequence.folder.files;return {complete:[...files.keys()].filter(name=>name.endsWith('.png')).length,sidecar:files.has('encode.sh')};});
 assert.ok(evidence.pngCancellation.complete>0&&evidence.pngCancellation.complete<120);
 assert.equal(evidence.pngCancellation.sidecar,false);
 assert.equal(await page.locator('#fibers').isEnabled(),true);
 log('Canceled PNG sequence retains only completed frames without claiming a finished loop');
 const mp4Wait=page.waitForEvent('download',{predicate:d=>d.suggestedFilename().endsWith('.mp4'),timeout:480000});await page.locator('#record').click();assert.equal(await page.locator('#fibers').isEnabled(),false);const mp4=await mp4Wait,mp4Path=path.join(output,'loom-720-30.mp4');await mp4.saveAs(mp4Path);await page.waitForFunction(()=>document.querySelector('#record').textContent==='Export MP4');assert.equal(await page.locator('#fibers').isEnabled(),true);assert.equal(await page.locator('#play').textContent(),'Play');
 evidence.mp4=probe(mp4Path);assert.equal(evidence.mp4.codec_name,'h264');assert.equal(evidence.mp4.width,720);assert.equal(evidence.mp4.height,720);assert.equal(evidence.mp4.r_frame_rate,'30/1');assert.equal(Number(evidence.mp4.nb_read_frames),120);assert.ok(Math.abs(Number(evidence.mp4.duration)-4)<.05);
 const decoded=execFileSync('ffmpeg',['-v','error','-i',mp4Path,'-vf','select=eq(n\\,0)+eq(n\\,60)+eq(n\\,119)','-vsync','0','-f','rawvideo','-pix_fmt','rgb24','pipe:1'],{maxBuffer:8*1024*1024,timeout:60000}),frameBytes=720*720*3;assert.equal(decoded.length,3*frameBytes);let lo=255,hi=0,change=0;for(let i=0;i<frameBytes;i++){lo=Math.min(lo,decoded[i]);hi=Math.max(hi,decoded[i]);change+=Math.abs(decoded[i]-decoded[i+frameBytes]);}assert.ok(hi-lo>32);assert.ok(change/frameBytes>.01);log('Actual shared-exporter MP4: H.264, 720 square, 30 FPS, 120 nonblank changing frames, four seconds');
 let canceledDownload=false;const onDownload=d=>{if(d.suggestedFilename().endsWith('.mp4'))canceledDownload=true;};page.on('download',onDownload);
 for(let attempt=0;attempt<2;attempt++){await page.locator('#record').click();await page.waitForFunction(()=>/Encoding/i.test(document.querySelector('#status').textContent),null,{timeout:60000});await page.locator('#record').click();await page.waitForFunction(()=>/cancel/i.test(document.querySelector('#status').textContent)&&document.querySelector('#record').textContent==='Export MP4');assert.equal(await page.locator('#fibers').isEnabled(),true);assert.equal(await page.locator('#play').textContent(),'Play');}
 await page.waitForTimeout(300);assert.equal(canceledDownload,false);page.off('download',onDownload);log('Repeated real-encoder cancellation restores controls without partial downloads');
 // A fresh page has no cached FrameWrap promise. Hold the initial CDN request
 // until after cancellation is confirmed, so encoder speed cannot mask the bug.
 const loadingPage=await context.newPage();let delayedRoute,releaseRoute;
 const routeSeen=new Promise(r=>{delayedRoute=r;}),routeRelease=new Promise(r=>{releaseRoute=r;});
 let lateDownloads=0;loadingPage.on('download',()=>lateDownloads++);
 await loadingPage.route('https://cdn.jsdelivr.net/npm/ccapture.js@2.0.0/build/ccapture.umd.min.js',async route=>{delayedRoute();await routeRelease;await route.fulfill({contentType:'application/javascript',body:'globalThis.CCapture={FrameWrap:class {constructor(){throw new Error("Canceled encoder must not start");}}};'});});
 try{
  await loadingPage.goto(url+'?phase=0&fibers=8&samples=128&duration=4');await loadingPage.locator('#fibers').waitFor();
  await loadingPage.locator('details').filter({has:loadingPage.locator('#exportSize')}).evaluate(el=>el.open=true);
  await loadingPage.locator('#record').click();
  await Promise.race([routeSeen,new Promise((_,reject)=>setTimeout(()=>reject(Error('Encoder CDN request was not intercepted')),10000))]);
  assert.equal(await loadingPage.locator('#fibers').isEnabled(),false);assert.match(await loadingPage.locator('#status').textContent(),/Loading/);
  await loadingPage.locator('#record').click();
  await loadingPage.waitForFunction(()=>document.querySelector('#record').textContent==='Export MP4'&&document.querySelector('#status').textContent==='Export canceled',null,{timeout:2000});
  assert.equal(await loadingPage.locator('#fibers').isEnabled(),true);assert.equal(await loadingPage.locator('#play').textContent(),'Play');assert.equal(lateDownloads,0);
  releaseRoute();await loadingPage.waitForFunction(()=>!!globalThis.CCapture);await settle(loadingPage);await loadingPage.waitForTimeout(100);
  assert.equal(await loadingPage.locator('#status').textContent(),'Export canceled');assert.equal(await loadingPage.locator('#record').textContent(),'Export MP4');assert.equal(lateDownloads,0);
  log('Cancel during delayed initial CDN load immediately unlocks controls and never starts encoder or downloads');
 }finally{releaseRoute();await loadingPage.close();}
 await page.goto(base+'/#scene=luminous-loom');await page.locator('#frame-host iframe').waitFor();assert.equal(await page.locator('iframe').count(),1);await page.locator('#back').click();assert.equal(await page.locator('iframe').count(),0);await page.locator('a.cover[href="#scene=luminous-loom"]').click();await page.locator('#frame-host iframe').waitFor();assert.equal(await page.locator('iframe').count(),1);await page.locator('#back').click();assert.equal(await page.locator('iframe').count(),0);log('Gallery destroys and reopens study with no hidden running iframe');
 await page.goto(base+'/#scene=luminous-loom');await page.locator('#frame-host iframe').waitFor();await page.frameLocator('#frame-host iframe').locator('header a').click();await page.waitForURL(base+'/index.html');assert.equal(await page.locator('iframe').count(),0);log('Study title exits to the top-level gallery instead of nesting another running scene');
 const mobile=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,isMobile:true,hasTouch:true,reducedMotion:'reduce'}),phone=await mobile.newPage();phone.on('pageerror',e=>errors.push(e.message));await phone.goto(url+'?phase=0&fibers=16&samples=128');await phone.locator('#fibers').waitFor();await settle(phone);assert.ok(await phone.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));const box=await phone.locator('aside').boundingBox();assert.ok(box.x>=0&&box.x+box.width<=390);assert.ok(box.height>0);await phone.locator('#hide').scrollIntoViewIfNeeded();await snapshot(phone,'mobile');await phone.locator('#hide').tap();assert.equal(await phone.locator('aside').isVisible(),false);assert.equal(await phone.locator('#show').isVisible(),true);assert.ok(Number(await phone.locator('#show').evaluate(el=>getComputedStyle(el).opacity))>0);await assertScene(phone,'mobile-clean',true);await snapshot(phone,'mobile-hidden');await phone.locator('#show').tap();assert.equal(await phone.locator('aside').isVisible(),true);await assertScene(phone,'mobile-restored');await snapshot(phone,'mobile-restored');await mobile.close();log('Mobile panel fits width, scrolls normally and visible hide/show works with touch');
 assert.deepEqual(errors,[]);console.log('LUMINOUS_LOOM_QA_SUCCESS');
})().catch(async error=>{console.error(error);if(page){await snapshot(page,'failure').catch(()=>{});console.error('STATUS '+await page.locator('#status').textContent({timeout:1000}).catch(()=>'(absent)'));}process.exitCode=1;}).finally(async()=>{await fs.mkdir(output,{recursive:true});await fs.writeFile(path.join(output,'summary.json'),JSON.stringify({results,errors,...evidence},null,2));await browser?.close();await new Promise(r=>server.close(r));clearTimeout(deadline);});
