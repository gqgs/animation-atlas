# chromatic-chamber source

Run `python3 -m http.server 8080` here and open http://localhost:8080/experiments/chromatic-chamber/. Keep the experiments/ and shared/ folders together. See experiments/chromatic-chamber/README.md.
