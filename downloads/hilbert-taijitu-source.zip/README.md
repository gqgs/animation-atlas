# EigenDynamics — Hilbert / Taijitu

Source is in experiments/hilbert-yin-yang/. Serve this directory with
`python3 -m http.server 8080` and open
`http://127.0.0.1:8080/experiments/hilbert-yin-yang/`.

This ZIP uses a CDN shim for Three.js only to keep the archive small;
in gqgs/eigendynamics, remove the shim and use the existing
`vendor/three.module.js` and `vendor/three.core.js` for offline use.

The single-file standalone HTML in the accompanying download
also loads Three.js from jsDelivr.
