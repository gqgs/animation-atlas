import test from 'node:test';
import assert from 'node:assert/strict';
import { hilbertCell, hilbertDiskPoints, squareToDisk, yinDivider, recursiveDisks, rimDisks, geometryStats, visibleDisks } from '../experiments/hilbert-yin-yang/geometry.mjs';

test('Hilbert order produces unique centers with Manhattan-adjacent steps', () => {
  for (let order = 1; order <= 6; order++) {
    const n = 4 ** order, seen = new Set();
    let prev = null;
    for (let i = 0; i < n; i++) {
      const curr = hilbertCell(i, order);
      assert.equal(curr.length, 2);
      assert.ok(curr.every(c => c >= 0 && c < 2 ** order));
      assert.ok(!seen.has(curr.join(',')));
      seen.add(curr.join(','));
      if (prev) assert.equal(Math.abs(curr[0] - prev[0]) + Math.abs(curr[1] - prev[1]), 1);
      prev = curr;
    }
    assert.equal(seen.size, n);
  }
});

test('square-to-disk warp stays in disk and reaches disk boundary', () => {
  for (let i = -20; i <= 20; i++) for (let j = -20; j <= 20; j++) {
    const [x, y] = squareToDisk(i / 20, j / 20);
    assert.ok(Number.isFinite(x) && Number.isFinite(y));
    assert.ok(Math.hypot(x, y) < 1.0000001);
  }
  assert.ok(Math.abs(Math.hypot(...squareToDisk(1, 1)) - 1) < 1e-12);
});

test('disk points count and position', () => {
  for (let n = 1; n <= 7; n++) {
    const points = hilbertDiskPoints(n);
    assert.equal(points.length, 2 * 4 ** n);
    for (let i = 0; i < points.length; i += 2)
      assert.ok(Math.hypot(points[i], points[i + 1]) <= 1.000001);
  }
});

test('yin-yang divider changes side across x=0', () => {
  assert.ok(yinDivider(-0.8, 0.2) < 0);
  assert.ok(yinDivider(0.8, 0.2) > 0);
  assert.ok(yinDivider(0, 0.5) < 0);
  assert.ok(yinDivider(0, -0.5) > 0);
});

test('recursive disk count and strict parental inclusion', () => {
  for (let d = 0; d <= 6; d++) {
    const disks = recursiveDisks(d);
    assert.equal(disks.length, 2 ** (d + 1) - 1);
    assert.deepEqual(disks[0], {x:0, y:0, radius:1, angle:0, level:0, sign:1});
    for (let i = 1; i < disks.length; i++) {
      const child = disks[i];
      assert.ok(Math.hypot(child.x, child.y) + child.radius < 1);
    }
  }
  assert.equal(rimDisks().length, 20);
  assert.equal(geometryStats(6, 3, true).disks, 35);
});

test('screen-space LOD drops subpixel descendants without losing root', () => {
  const all = recursiveDisks(4);
  assert.equal(all.length, 31);
  assert.equal(visibleDisks(all, 200, 2).length, 15);
  assert.equal(visibleDisks(all, 1000, 2).length, 31);
  assert.equal(visibleDisks(all, 5, 2).length, 1);
});
