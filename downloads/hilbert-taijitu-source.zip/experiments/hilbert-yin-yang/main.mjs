import * as THREE from '../../vendor/three.module.js';
import { hilbertDiskPoints, recursiveDisks, rimDisks, visibleDisks } from './geometry.mjs';

/* No geometry randomness: identical settings produce identical curve paths. */
const $ = id => document.getElementById(id);
const canvas = $('canvas');
const shell = $('scene-shell');
const errorBox = $('canvas-error');
const defaults = { order: 6, depth: 3, childScale: 0.222, twist: 2.20, speed: 0.65, rim: true, flow: true };
const state = { ...defaults };
let renderer, scene, camera, field, stars, frameId = 0, paused = false, t = 0, lastFrame = 0;
let frameCounter = 0, fpsTick = 0, yaw = 0, zoom = 1, rebuildPending = false;
const timeUniform = { value: 0 };
const twistUniform = { value: state.twist };
const speedUniform = { value: state.speed };
const geomCache = new Map();
const disposal = [];
const orbitDisposal = [];
const GOLD = new THREE.Color('#ffab4e');
const BLUE = new THREE.Color('#49bdff');
const formatInt = n => new Intl.NumberFormat('en-US').format(n);
const fmt = t => `00:${String(Math.floor(t) % 60).padStart(2, '0')}`;

const diskVS = `
  varying vec2 vPos;
  void main() {
    vPos = uv * 2.4 - 1.2;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
const yinFunction = `
  float divider(vec2 p) {
    float rad = sqrt(max(0.0, 0.25 - pow(abs(p.y) - 0.5, 2.0)));
    return p.x - (p.y >= 0.0 ? rad : -rad);
  }
  vec3 shade(vec2 p, float flip, vec3 gold, vec3 blue) {
    float c = smoothstep(-0.018, 0.018, -divider(p));
    return mix(blue, gold, flip > 0.0 ? c : 1.0 - c);
  }
`;
const diskFS = `
  precision highp float;
  varying vec2 vPos;
  uniform vec3 uGold, uBlue;
  uniform float uTime, uSpeed, uFlip, uPhase;
  ${yinFunction}
  void main() {
    float r = length(vPos);
    if (r > 1.018) discard;
    float d = divider(vPos);
    vec3 base = shade(vPos, uFlip, uGold, uBlue);
    float rim = exp(-pow((r - 0.978) * 76.0, 2.0));
    float seam = exp(-abs(d) * 26.0);
    float aperture = 0.18 + 0.25 * (1.0 - r);
    float radial = 0.66 + 0.25 * cos(13.0 * r - uTime * 0.35 * uSpeed + uPhase);
    float sheen = 0.85 + 0.15 * sin(18.0 * atan(vPos.y, vPos.x) + uTime * 0.17 * uSpeed);
    vec3 col = base * (aperture + radial * 0.15 + rim * 1.55 + seam * 0.50) * sheen;
    col += vec3(0.075, 0.115, 0.18) * (1.0 - smoothstep(0.0, 0.97, r));
    float a = 0.965 * (1.0 - smoothstep(0.99, 1.02, r));
    gl_FragColor = vec4(col, a);
  }
`;
const haloFS = `
  precision highp float;
  varying vec2 vPos;
  uniform vec3 uGold, uBlue;
  uniform float uTime, uSpeed, uPhase;
  void main() {
    float r = length(vPos);
    float a = atan(vPos.y, vPos.x);
    float ring = exp(-pow((r - 1.01) * 22.0, 2.0)) * 0.27;
    float haze = exp(-pow((r - 0.99) * 5.0, 2.0)) * 0.075;
    float pulse = 0.8 + 0.2 * sin(uTime * uSpeed + uPhase);
    vec3 tint = mix(uGold, uBlue, smoothstep(-0.38, 0.42, cos(a - 0.8)));
    gl_FragColor = vec4(tint * 1.7, (ring + haze) * pulse);
  }
`;
const ribbonVS = `
  precision highp float;
  attribute vec2 aFrom;
  attribute vec2 aTo;
  attribute float aEnd;
  attribute float aSide;
  attribute float aParam;
  varying vec2 vPos;
  varying float vEdge;
  varying float vParam;
  uniform float uTwist, uMotion, uTime, uThickness, uPhase;
  vec2 twist(vec2 p) {
    float r = length(p);
    float angle = uTwist * pow(max(0.0, 1.0 - r), 1.75) +
      0.10 * uMotion * sin(uTime * 0.42 + r * 7.0 + uPhase) * (1.0 - r);
    float s = sin(angle), c = cos(angle);
    return vec2(c * p.x - s * p.y, s * p.x + c * p.y);
  }
  void main() {
    vec2 a = twist(aFrom);
    vec2 b = twist(aTo);
    vec2 delta = b - a;
    vec2 n = vec2(-delta.y, delta.x) / max(length(delta), 0.000001);
    vec2 p = mix(a, b, aEnd) + n * aSide * uThickness;
    vPos = p;
    vEdge = aSide;
    vParam = aParam;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 0.011, 1.0);
  }
`;
const ribbonFS = `
  precision highp float;
  varying vec2 vPos;
  varying float vEdge;
  varying float vParam;
  uniform vec3 uGold, uBlue;
  uniform float uFlip, uTime, uMotion, uPhase, uOpacity;
  ${yinFunction}
  void main() {
    float center = 1.0 - smoothstep(0.40, 1.0, abs(vEdge));
    float pulse = pow(0.5 + 0.5 * sin(vParam * 99.0 - uTime * uMotion * 4.5 + uPhase), 8.0);
    vec3 col = shade(vPos, uFlip, uGold, uBlue);
    col *= 1.2 + pulse * 1.6;
    gl_FragColor = vec4(col, center * uOpacity * (0.70 + pulse * 0.35));
  }
`;
const starsVS = `
  attribute float aSize;
  attribute float aPhase;
  varying float vLight;
  uniform float uTime;
  uniform float uDpr;
  void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = aSize * uDpr * (0.8 + 0.2 * sin(uTime * 0.62 + aPhase));
    vLight = 0.65 + 0.35 * sin(uTime * 0.9 + aPhase);
  }
`;
const starsFS = `
  precision mediump float;
  varying float vLight;
  void main() {
    float r = length(gl_PointCoord - 0.5) * 2.0;
    float a = exp(-r * r * 6.0) * (1.0 - smoothstep(0.8, 1.0, r));
    gl_FragColor = vec4(0.62, 0.79, 1.0, a * vLight * 0.8);
  }
`;
const nebulaFS = `
  precision highp float;
  varying vec2 vPos;
  uniform float uTime, uSpeed;
  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  void main() {
    vec2 p = vPos;
    float r = length(p);
    float a = atan(p.y, p.x);
    float spiral = sin(a * 4.0 + r * 11.0 - uTime * 0.025 * uSpeed);
    float clouds = 0.5 + 0.5 * sin(p.x * 10.0 + cos(p.y * 7.0 + spiral));
    float g = exp(-r * 1.5) * (0.1 + 0.5 * smoothstep(-0.35, 1.0, spiral)) * clouds;
    vec3 col = mix(vec3(0.024, 0.050, 0.12), vec3(0.18, 0.075, 0.043), smoothstep(-0.5, 0.7, -p.x));
    gl_FragColor = vec4(col * (0.14 + g * 0.52), 0.7);
  }
`;

function ribbonGeometry(order) {
  if (geomCache.has(order)) return geomCache.get(order);
  const points = hilbertDiskPoints(order);
  const count = points.length / 2 - 1;
  const from = new Float32Array(count * 8);
  const to = new Float32Array(count * 8);
  const end = new Float32Array(count * 4);
  const side = new Float32Array(count * 4);
  const param = new Float32Array(count * 4);
  const indices = new Uint32Array(count * 6);
  for (let i = 0; i < count; i++) {
    const k = i * 4;
    for (let j = 0; j < 4; j++) {
      from[2 * (k + j)] = points[2 * i];
      from[2 * (k + j) + 1] = points[2 * i + 1];
      to[2 * (k + j)] = points[2 * (i + 1)];
      to[2 * (k + j) + 1] = points[2 * (i + 1) + 1];
      end[k + j] = j >= 2 ? 1 : 0;
      side[k + j] = j % 2 === 0 ? -1 : 1;
      param[k + j] = (i + end[k + j]) / count;
    }
    indices.set([k, k + 1, k + 2, k + 2, k + 1, k + 3], i * 6);
  }
  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.BufferAttribute(new Float32Array(count * 4 * 3), 3));
  geom.setAttribute('aFrom', new THREE.BufferAttribute(from, 2));
  geom.setAttribute('aTo', new THREE.BufferAttribute(to, 2));
  geom.setAttribute('aEnd', new THREE.BufferAttribute(end, 1));
  geom.setAttribute('aSide', new THREE.BufferAttribute(side, 1));
  geom.setAttribute('aParam', new THREE.BufferAttribute(param, 1));
  geom.setIndex(new THREE.BufferAttribute(indices, 1));
  geom.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1.5);
  geomCache.set(order, geom);
  return geom;
}
function uniformPack(sign, phase) {
  return {
    uGold: { value: GOLD }, uBlue: { value: BLUE },
    uTime: timeUniform, uTwist: twistUniform, uMotion: speedUniform,
    uSpeed: speedUniform, uFlip: { value: sign },
    uPhase: { value: phase },
  };
}
function trackedMaterial(options) {
  const m = new THREE.ShaderMaterial(options);
  disposal.push(m);
  return m;
}
function addDisc(disk, order) {
  const group = new THREE.Group();
  group.position.set(disk.x, disk.y, 0);
  group.rotation.z = disk.angle;
  group.scale.setScalar(disk.radius);
  field.add(group);
  const phase = disk.level * 1.3 + disk.x * 2.0 + disk.y * 4.0;
  const common = uniformPack(disk.sign, phase);
  const halo = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 2.4), trackedMaterial({
    vertexShader: diskVS, fragmentShader: haloFS,
    uniforms: common, transparent: true, depthWrite: false, depthTest: false,
    blending: THREE.AdditiveBlending,
  }));
  halo.renderOrder = 5 + disk.level * 10;
  group.add(halo);
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 2.4), trackedMaterial({
    vertexShader: diskVS, fragmentShader: diskFS,
    uniforms: common, transparent: true, depthWrite: false, depthTest: false,
  }));
  plane.renderOrder = 6 + disk.level * 10;
  group.add(plane);
  const lineOrder = disk.rim ? 2 : Math.max(1, order - disk.level);
  const thickness = Math.min(0.064, 0.0024 / disk.radius);
  const lineCommon = uniformPack(disk.sign, phase);
  const geometry = ribbonGeometry(lineOrder);
  for (const [width, opacity, rank] of [[4.5, 0.14, 7], [1.3, 0.64, 8]]) {
    const trail = new THREE.Mesh(geometry, trackedMaterial({
      vertexShader: ribbonVS, fragmentShader: ribbonFS,
      uniforms: { ...lineCommon, uThickness: { value: thickness * width }, uOpacity: { value: opacity } },
      transparent: true, depthWrite: false, depthTest: false,
      blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    }));
    trail.renderOrder = rank + disk.level * 10;
    trail.visible = state.flow || width < 2;
    trail.userData.isGlow = width > 2;
    group.add(trail);
  }
  // Plane geometries are per-disk, not part of the cached Hilbert path geometries.
  group.userData.planeGeometries = [halo.geometry, plane.geometry];
}
function clearField() {
  if (!field) return;
  for (const disc of [...field.children]) {
    for (const geom of disc.userData.planeGeometries || []) geom.dispose();
    field.remove(disc);
  }
  for (const m of disposal) m.dispose();
  disposal.length = 0;
}
function rebuild() {
  if (!field) return;
  clearField();
  const all = recursiveDisks(state.depth, state.childScale);
  if (state.rim) all.push(...rimDisks(20));
  const aspect = Math.max(0.1, shell.clientWidth / Math.max(1, shell.clientHeight));
  const halfH = Math.max(1.42, 1.42 / aspect);
  const pxPerUnit = shell.clientHeight * zoom / (2 * halfH);
  const visible = visibleDisks(all, pxPerUnit, 2);
  // Deeper components occlude the parent rather than being buried beneath it.
  visible.forEach(d => addDisc(d, state.order));
  const segments = visible.reduce((sum, d) => sum + (4 ** (d.rim ? 2 : Math.max(1, state.order - d.level)) - 1), 0);
  $('segment-count').textContent = formatInt(segments);
  $('disk-count').textContent = formatInt(visible.length);
  $('shape-status').textContent = `H${state.order} · ${formatInt(4 ** state.order)} SAMPLES`;
}
function scheduleRebuild() {
  if (rebuildPending) return;
  rebuildPending = true;
  requestAnimationFrame(() => { rebuildPending = false; rebuild(); });
}
function randGenerator(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ a >>> 15, 1 | a);
    t ^= t + Math.imul(t ^ t >>> 7, 61 | t); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
function createStarfield() {
  const rng = randGenerator(20261021);
  const N = 720, positions = new Float32Array(N * 3), sizes = new Float32Array(N), phases = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    positions[i * 3] = (rng() - 0.5) * 7.6;
    positions[i * 3 + 1] = (rng() - 0.5) * 5.3;
    positions[i * 3 + 2] = -0.7;
    sizes[i] = rng() < 0.04 ? 4.5 : 1.0 + 2.1 * rng();
    phases[i] = rng() * 6.28318;
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geometry.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
  const material = new THREE.ShaderMaterial({
    vertexShader: starsVS, fragmentShader: starsFS,
    uniforms: { uTime: timeUniform, uDpr: { value: Math.min(window.devicePixelRatio || 1, 2) } },
    blending: THREE.AdditiveBlending, transparent: true, depthWrite: false,
  });
  stars = new THREE.Points(geometry, material);
  stars.renderOrder = 0;
  scene.add(stars);
}
function createNebula() {
  // A faint WebGL background means the PNG export includes the environment.
  const geo = new THREE.PlaneGeometry(7.3, 7.3);
  const mat = new THREE.ShaderMaterial({
    vertexShader: diskVS, fragmentShader: nebulaFS,
    uniforms: {uTime:timeUniform,uSpeed:speedUniform},
    transparent:true,depthWrite:false,depthTest:false,
  });
  const m = new THREE.Mesh(geo, mat);
  m.position.z = -0.9;
  m.renderOrder = -1;
  scene.add(m);
}
function createOrbits() {
  const orbitGroup = new THREE.Group();
  scene.add(orbitGroup);
  orbitGroup.userData.planeGeometries = [];
  for (const [r, opacity] of [[1.033, 0.17],[1.055,0.08],[1.108,0.032]]) {
    const points = Array.from({length:384},(_,i)=>{
      const theta = 2 * Math.PI * i / 384;
      return new THREE.Vector3(r * Math.cos(theta), r * Math.sin(theta), -0.06);
    });
    const geom = new THREE.BufferGeometry().setFromPoints(points);
    const material = new THREE.LineBasicMaterial({color:0xc9b0a3, transparent:true, opacity,
      blending:THREE.AdditiveBlending,depthTest:false,depthWrite:false});
    const loop = new THREE.LineLoop(geom,material);
    loop.renderOrder = 2;
    orbitGroup.add(loop);
    orbitDisposal.push(material, geom);
  }
}
function resize() {
  if (!renderer) return;
  const w = Math.max(1, shell.clientWidth), h = Math.max(1, shell.clientHeight);
  const aspect = w / h;
  const halfH = Math.max(1.42, 1.42 / aspect);
  camera.left = -halfH * aspect;
  camera.right = halfH * aspect;
  camera.top = halfH;
  camera.bottom = -halfH;
  camera.zoom = zoom;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h, false);
}
function bindControls() {
  const rangeIds = [['order', v=>Math.round(v), true], ['depth', v=>Math.round(v), true],
    ['child-scale', v=>v, true], ['twist', v=>v, false], ['speed', v=>v, false]];
  for (const [id, convert, needsRebuild] of rangeIds) {
    const element = $(id), output = $(id + '-value');
    element.addEventListener('input', () => {
      const value = convert(+element.value);
      const key = id === 'child-scale' ? 'childScale' : id;
      state[key] = value;
      output.textContent = id === 'order' || id === 'depth' ? String(value)
        : value.toFixed(id === 'child-scale' ? 3 : 2);
      twistUniform.value = state.twist;
      speedUniform.value = state.speed;
      if (needsRebuild) scheduleRebuild();
      updateUrl(false);
    });
  }
  for (const id of ['rim','flow']) {
    $(id).addEventListener('change', () => {
      state[id] = $(id).checked;
      if (id === 'rim') scheduleRebuild();
      else field.traverse(child => { if (child.userData?.isGlow) child.visible = state.flow; });
      updateUrl(false);
    });
  }
  $('pause').addEventListener('click', () => {
    paused = !paused;
    $('pause').textContent = paused ? '▶' : 'Ⅱ';
    $('pause').setAttribute('aria-label', paused ? 'Play animation' : 'Pause animation');
  });
  $('restart').addEventListener('click', () => { t = 0; timeUniform.value = t; $('time').value = 0; });
  $('reset-view').addEventListener('click', () => { yaw = 0; zoom = 1; field.rotation.z = 0; resize(); scheduleRebuild(); });
  $('time').addEventListener('input', () => { t = Number($('time').value); timeUniform.value = t; $('time-value').textContent = fmt(t); });
  $('snapshot').addEventListener('click', () => {
    renderer.render(scene, camera);
    const link = document.createElement('a');
    link.download = `eigendynamics-hilbert-taijitu-h${state.order}-d${state.depth}.png`;
    link.href = renderer.domElement.toDataURL('image/png');
    link.click();
  });
  $('copy-link').addEventListener('click', async () => {
    updateUrl(true);
    try { await navigator.clipboard.writeText(location.href); toast('Parameter link copied.'); }
    catch { toast('Copy the current browser URL.'); }
  });
  const presets = {
    atlas: {order:6,depth:3,childScale:0.222,twist:2.2,speed:0.65,rim:true,flow:true},
    spiral: {order:7,depth:2,childScale:0.24,twist:5.2,speed:1.35,rim:true,flow:true},
    pure: {order:6,depth:0,childScale:0.222,twist:0,speed:0,rim:false,flow:false},
  };
  document.querySelectorAll('[data-preset]').forEach(button=>button.addEventListener('click',()=>{
    Object.assign(state,presets[button.dataset.preset]);
    reflectControls();
    scheduleRebuild();
    updateUrl(false);
  }));
  const pointer = {x:0,dragging:false};
  canvas.addEventListener('pointerdown', e => {pointer.dragging=true;pointer.x=e.clientX;canvas.setPointerCapture(e.pointerId);});
  canvas.addEventListener('pointermove', e => {
    if (!pointer.dragging) return;
    yaw += (e.clientX-pointer.x)*0.003;
    pointer.x=e.clientX;
  });
  canvas.addEventListener('pointerup', () => {pointer.dragging=false;});
  canvas.addEventListener('pointercancel', () => {pointer.dragging=false;});
  canvas.addEventListener('wheel', e=>{e.preventDefault();zoom=THREE.MathUtils.clamp(zoom*Math.exp(-e.deltaY*0.0009),0.72,2.8);resize();scheduleRebuild();},{passive:false});
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    paused=true;$('pause').textContent='▶';$('pause').setAttribute('aria-label','Play animation');
  }
}
function reflectControls() {
  for (const [id,key,places] of [['order','order',0],['depth','depth',0],
    ['child-scale','childScale',3],['twist','twist',2],['speed','speed',2]]) {
    $(id).value = state[key];
    $(id+'-value').textContent = state[key].toFixed(places);
  }
  $('rim').checked=state.rim;$('flow').checked=state.flow;
  twistUniform.value=state.twist;speedUniform.value=state.speed;
}
function updateUrl(push) {
  const url = new URL(location.href);
  for (const [key,val] of Object.entries(state)) url.searchParams.set(key,String(val));
  if (push) history.replaceState(null, '', url.toString());
}
function readUrl() {
  const search = new URLSearchParams(location.search);
  for (const key of ['order','depth','childScale','twist','speed']) {
    if (!search.has(key)) continue;
    const n=Number(search.get(key));
    const bounds={order:[1,7],depth:[0,4],childScale:[.15,.32],twist:[0,6],speed:[0,2]};
    if (Number.isFinite(n)) state[key]=THREE.MathUtils.clamp(n,...bounds[key]);
  }
  state.order=Math.round(state.order);state.depth=Math.round(state.depth);
  for (const key of ['rim','flow']) if (search.has(key)) state[key]=search.get(key)==='true';
}
function toast(message) { $('toast').textContent=message; setTimeout(()=>{$('toast').textContent='';},2400); }
function animate(now) {
  frameId=requestAnimationFrame(animate);
  const dt=Math.min(0.050,(now-(lastFrame||now))/1000);
  lastFrame=now;
  if (!paused) t=(t+dt)%30;
  timeUniform.value=t;
  if (field) field.rotation.z=yaw+0.025*Math.sin(t*.24*state.speed);
  renderer.render(scene,camera);
  frameCounter++;
  if (now-fpsTick>1000) {
    $('frame-fps').textContent=`${Math.round(frameCounter*1000/Math.max(1,now-fpsTick))} FPS`;
    frameCounter=0;fpsTick=now;
  }
  $('time').value=t;
  $('time-value').textContent=fmt(t);
}
function start() {
  try {
    if (!window.WebGLRenderingContext) throw new Error('WebGL is not available in this browser.');
    renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'high-performance',preserveDrawingBuffer:true});
    renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));
    renderer.setClearColor(0x02040b, 1);
    renderer.outputColorSpace=THREE.SRGBColorSpace;
    scene=new THREE.Scene();
    camera=new THREE.OrthographicCamera(-1.5,1.5,1.5,-1.5,0.1,20);
    camera.position.set(0,0,7);camera.lookAt(0,0,0);
    field=new THREE.Group();scene.add(field);
    readUrl();bindControls();reflectControls();
    createNebula();createStarfield();rebuild();createOrbits();resize();
    new ResizeObserver(resize).observe(shell);
    frameId=requestAnimationFrame(animate);
    window.addEventListener('pagehide',()=>{
      cancelAnimationFrame(frameId);clearField();
      for (const geom of geomCache.values()) geom.dispose();
      for (const item of orbitDisposal) item.dispose();
      stars.geometry.dispose();stars.material.dispose();renderer.dispose();
    },{once:true});
  } catch (error) {
    errorBox.hidden=false;
    errorBox.textContent='Renderer initialization failed.\n'+(error?.message||String(error))+'\n\nServe this experiment from the repository root using a local HTTP server; do not open it with file://.';
    console.error(error);
  }
}
start();
