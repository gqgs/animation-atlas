import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { hilbertDiskPoints, yinDivider, recursiveDisks, rimDisks } from '../geometry.mjs';

const DIM = 900, CX = 450, CY = 450, R = 335;
function warp(x, y, amount=2.2) {
  const r=Math.hypot(x,y), a=amount*Math.pow(Math.max(0,1-r),1.75);
  return [Math.cos(a)*x-Math.sin(a)*y,Math.sin(a)*x+Math.cos(a)*y];
}
function hilbertPaths(order, twist=2.2) {
  const pts=hilbertDiskPoints(order), gold=[], blue=[];
  for(let i=0;i<pts.length/2-1;i++) {
    const a=warp(pts[i*2],pts[i*2+1],twist), b=warp(pts[i*2+2],pts[i*2+3],twist);
    const entry=`M${a[0].toFixed(4)},${a[1].toFixed(4)}L${b[0].toFixed(4)},${b[1].toFixed(4)}`;
    (yinDivider((a[0]+b[0])/2,(a[1]+b[1])/2)<0?gold:blue).push(entry);
  }
  return [gold.join(''),blue.join('')];
}
function orangeShape() {
  const pts=[];
  for(let i=0;i<=180;i++) {
    const y=-1+2*i/180;
    const f=Math.sqrt(Math.max(0,.25-(Math.abs(y)-.5)**2))*(y>=0?1:-1);
    pts.push([f,y]);
  }
  for(let i=0;i<=180;i++){
    const a=Math.PI/2+Math.PI*i/180;
    pts.push([Math.cos(a),Math.sin(a)]);
  }
  return `M${pts.map(([x,y])=>`${x.toFixed(4)},${y.toFixed(4)}`).join('L')}Z`;
}
const rng=(()=>{let seed=20261021;return ()=> { seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t^=t+Math.imul(t^t>>>7,61|t);return ((t^t>>>14)>>>0)/4294967296;};})();
const stars=Array.from({length:270},()=>{
  const x=(rng()*DIM).toFixed(2),y=(rng()*DIM).toFixed(2),r=(.2+rng()*1.05).toFixed(2),a=(.16+rng()*.52).toFixed(2);
  return `<circle cx="${x}" cy="${y}" r="${r}" fill="#b8d6fe" opacity="${a}"/>`;
}).join('');
const [g,b]=hilbertPaths(5),[sGold,sBlue]=hilbertPaths(3,1.5);
const orange=orangeShape();
const discs=[...recursiveDisks(2),...rimDisks(20)];
const contents=discs.map((d,i)=>{
  const scale=R*d.radius,x=CX+R*d.x,y=CY-R*d.y;
  const stroke=Math.max(.012,1.5/(scale));
  if(i===0) return `
    <g transform="translate(${x},${y}) scale(${scale},${-scale})">
      <circle r="1.01" fill="#1a3760"/><path d="${orange}" fill="#a85318"/>
      <circle r="1" fill="none" stroke="#bda684" stroke-width=".015" opacity=".9"/>
      <path d="${g}" fill="none" stroke="#ffbe61" stroke-width=".007" opacity=".9" stroke-linejoin="round"/>
      <path d="${b}" fill="none" stroke="#81d8ff" stroke-width=".007" opacity=".9" stroke-linejoin="round"/>
    </g>`;
  return `<g transform="translate(${x.toFixed(2)},${y.toFixed(2)}) rotate(${(d.angle*180/Math.PI).toFixed(3)}) scale(${scale.toFixed(3)},${(-scale).toFixed(3)})">
    <circle r="1" fill="${d.sign>0?'#133560':'#522b12'}"/><path d="${orange}" fill="${d.sign>0?'#ad611d':'#1686bf'}"/>
    <use href="#miniGold" fill="none" stroke="${d.sign>0?'#ffc878':'#8fdcff'}" stroke-width="${Math.min(stroke,.055).toFixed(4)}" opacity=".95"/>
    <use href="#miniBlue" fill="none" stroke="${d.sign>0?'#91d6ff':'#ffd291'}" stroke-width="${Math.min(stroke,.055).toFixed(4)}" opacity=".95"/>
    <circle r=".99" fill="none" stroke="#d9dcf5" stroke-width=".045" opacity=".4"/>
  </g>`;
}).join('');
const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${DIM} ${DIM}" role="img" aria-label="Programmatic preview of the Hilbert / Taijitu fractal, from the same Hilbert geometry used by the experiment">
  <defs>
    <path id="miniGold" d="${sGold}"/>
    <path id="miniBlue" d="${sBlue}"/>
    <radialGradient id="sky"><stop stop-color="#122445"/><stop offset=".58" stop-color="#080e21"/><stop offset="1" stop-color="#03070f"/></radialGradient>
    <radialGradient id="aura"><stop stop-color="#e39552" stop-opacity=".16"/><stop offset=".63" stop-color="#4c9edb" stop-opacity=".12"/><stop offset="1" stop-color="#61b6ff" stop-opacity="0"/></radialGradient>
    <filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="10"/></filter>
  </defs>
  <rect width="900" height="900" fill="url(#sky)"/>
  ${stars}
  <circle cx="450" cy="450" r="430" fill="url(#aura)"/>
  <circle cx="450" cy="450" r="335" fill="none" stroke="#9cceff" stroke-width="27" opacity=".22" filter="url(#glow)"/>
  ${contents}
  <circle cx="450" cy="450" r="338" fill="none" stroke="#a0c5ec" stroke-width="2" opacity=".8"/>
  <circle cx="450" cy="450" r="350" fill="none" stroke="#89a8de" stroke-width="1" opacity=".12"/>
  <g font-family="Georgia,serif" fill="#dae6f7"><text x="50" y="67" font-size="30" letter-spacing="2">HILBERT / TAIJITU</text>
  <text x="53" y="97" font-family="monospace" font-size="12" fill="#91a3bc" letter-spacing="2.4">EIGENDYNAMICS · RECURSIVE FRACTAL STUDY</text></g>
  <g font-family="monospace" font-size="12" fill="#8c9cb7" letter-spacing="1.5"><text x="53" y="840">Hₙ → H    ·    SQUARE → DISK</text>
  <text x="849" y="840" text-anchor="end">ANIMATION ATLAS / 012</text></g>
</svg>\n`;
const output=resolve(dirname(fileURLToPath(import.meta.url)),'../preview.svg');
fs.writeFileSync(output,svg);
console.log(`Generated ${output} (${svg.length} chars)`);
