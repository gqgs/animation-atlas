/**
 * Discrete Hilbert centers, continuously warped to a disk, plus an explicitly
 * finite recursive family of embedded disks. Deterministic, DOM/Three-free.
 * See README.md for mathematical and rendering assumptions.
 */
export function hilbertCell(index, order) {
  if (!Number.isInteger(order) || order < 1 || order > 8) throw new RangeError('order must be 1..8');
  const side = 2 ** order;
  if (!Number.isInteger(index) || index < 0 || index >= side * side) throw new RangeError('index outside curve');
  let x = 0, y = 0, t = index;
  for (let s = 1; s < side; s *= 2) {
    const rx = 1 & Math.floor(t / 2);
    const ry = 1 & (t ^ rx);
    if (ry === 0) {
      if (rx === 1) { x = s - 1 - x; y = s - 1 - y; }
      [x, y] = [y, x];
    }
    x += s * rx;
    y += s * ry;
    t = Math.floor(t / 4);
  }
  return [x, y];
}

/** FG-squircle square-to-disk map, continuous and surjective on [-1,1]^2. */
export function squareToDisk(x, y) {
  return [x * Math.sqrt(Math.max(0, 1 - y * y / 2)),
          y * Math.sqrt(Math.max(0, 1 - x * x / 2))];
}

export function hilbertDiskPoints(order) {
  const side = 2 ** order;
  const count = side ** 2;
  const out = new Float32Array(count * 2);
  for (let i = 0; i < count; i++) {
    const [cx, cy] = hilbertCell(i, order);
    const x = 2 * (cx + 0.5) / side - 1;
    const y = 2 * (cy + 0.5) / side - 1;
    const [dx, dy] = squareToDisk(x, y);
    out[i * 2] = dx;
    out[i * 2 + 1] = dy;
  }
  return out;
}

/** Signed horizontal distance from the conventional vertical S-shaped divider. */
export function yinDivider(x, y) {
  const ay = Math.abs(y);
  const q = Math.sqrt(Math.max(0, 0.25 - (ay - 0.5) ** 2));
  return x - (y >= 0 ? q : -q);
}

/**
 * Recursion uses a self-similar placement operator. Each child is strictly
 * inside its parent; visual LOD may stop early without affecting the model.
 */
export function recursiveDisks(depth, scale = 0.222) {
  if (!Number.isInteger(depth) || depth < 0 || depth > 6) throw new RangeError('depth must be 0..6');
  if (!(scale > 0 && scale < 0.48)) throw new RangeError('scale must be (0,.48)');
  const disks = [];
  function recurse(x, y, radius, angle, level, sign) {
    disks.push({ x, y, radius, angle, level, sign });
    if (level === depth) return;
    for (const offset of [0.515, -0.515]) {
      const dx = -Math.sin(angle) * offset * radius;
      const dy = Math.cos(angle) * offset * radius;
      recurse(x + dx, y + dy, radius * scale,
        angle + (offset > 0 ? -0.34 : 0.34), level + 1,
        -sign);
    }
  }
  recurse(0, 0, 1, 0, 0, 1);
  return disks;
}

export function rimDisks(count = 20) {
  if (!Number.isInteger(count) || count < 0 || count > 40) throw new RangeError('count must be 0..40');
  return Array.from({ length: count }, (_, i) => {
    const a = -Math.PI / 2 + i * Math.PI * 2 / count;
    const r = 0.877;
    return {
      x: r * Math.cos(a), y: r * Math.sin(a),
      radius: 0.061, angle: -a * 0.7, level: 2,
      sign: i % 2 === 0 ? 1 : -1, rim: true,
    };
  });
}

/** The renderer can skip copies smaller than the chosen screen-space radius. */
export function visibleDisks(disks, pixelsPerUnit, minimumRadiusPx = 2.0) {
  if (!Number.isFinite(pixelsPerUnit) || pixelsPerUnit <= 0) throw new RangeError('positive pixel scale required');
  return disks.filter(d => d.level === 0 || d.radius * pixelsPerUnit >= minimumRadiusPx);
}

/** Counts only whole path segments, not GPU triangles or decorative rings. */
export function geometryStats(order, depth, withRim = true) {
  const disks = recursiveDisks(depth);
  const diskSegments = disks.reduce((sum, d) => sum + (4 ** Math.max(1, order - d.level) - 1), 0);
  const rimSegments = withRim ? 20 * (4 ** 2 - 1) : 0;
  return { disks: disks.length + (withRim ? 20 : 0), segments: diskSegments + rimSegments,
    mainPoints: 4 ** order };
}
