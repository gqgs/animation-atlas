# Hilbert / Taijitu — EigenDynamics Animation Atlas

An isolated Three.js r180 study of a genuine finite Hilbert curve approximation,
continuously warped into the unit disk and repeated by a geometric recursion.
The palette and S-shaped boundary produce a nested yin-yang mandala.

## Run from the EigenDynamics repository

```sh
python3 -m http.server 8080
# http://127.0.0.1:8080/experiments/hilbert-yin-yang/
```

`main.mjs` imports `../../vendor/three.module.js`, reusing the repository's
local Three.js r180 implementation (`three.core.js` alongside it).
No installation, account or external service is required.

The separate standalone HTML export provided with the PoC uses a CDN
for Three.js so it can be opened directly, but the repository experiment
uses the existing local vendor and requires no network.

## Mathematics

1. For order `n`, the standard Hilbert index-to-cell algorithm traverses all
   `4^n` centers of a `2^n × 2^n` grid with Manhattan-adjacent steps.
   The connected polyline is a finite approximation, not itself a
   space-filling curve.
2. Map normalized square coordinates `(x,y)` into the disk via the
   Fernández-Guasti (FG) squircle map:

   `W(x,y) = (x sqrt(1-y²/2), y sqrt(1-x²/2))`.

   The warp is continuous on the square. Applying it to a continuous
   Hilbert limit produces a continuous surjection onto the disk.
3. Deform the disk paths with a continuous radial twist, preserving
   path continuity for each fixed time.
4. Independently recurse two child disks of relative radius `s` at local
   `(0, ±0.515)`, rotated by small opposite angles. With `s=.222`, each
   child is strictly contained in its parent. Optionally add twenty
   non-recursive copies along the rim.
5. Color by the signed distance to the S-shaped divider (in local disk
   coordinates), avoiding clipping paths into disconnected pieces.

`geometry.mjs` is pure and deterministic, suitable for reusing in future
projectile and procedural material experiments. `main.mjs` isolates the
renderer, shaders, GUI and export controls.

## Controls and limits

- Hilbert order 1–7; geometric recursion depth 0–4; child scale .15–.32;
  radial twist 0–6; flow speed 0–2.
- Toggle rim copies and glow, select presets, pause, seek, drag to rotate,
  wheel to zoom, save PNG, and copy a parameterized URL.
- Curves use cached indexed GPU ribbons; the twist is applied in the vertex
  shader. No per-frame curve regeneration.
- Descendant disks with projected radius below 2 px are culled; the root
  remains visible. This is visual LOD, not a change to recursive geometry.
- `npm` not needed for this stand-alone source. Validate mathematics with
  `node --test tests/hilbert-yin-yang.test.mjs` from the repository root.
- At high order and depth, the fragment workload and draw-call count may
  become expensive. No collision geometry is generated; this is a visual PoC.

## Animation Atlas catalog record

`atlas-entry.json` is a record ready for the separate hosted Animation Atlas.
The actual Atlas site is independently hosted and is not stored in the game
repository. Register the HTML page as an experiment before claiming it is
live in the gallery. `preview.svg` is algorithmically derived from the same Hilbert cells,
warp and recursion rules; regenerate with `node experiments/hilbert-yin-yang/tools/build-preview.mjs`.
It is a deterministic catalog thumbnail, not a Three.js browser screenshot.

The research goal is to validate geometry and visual potential. It does not
block or alter the EigenDynamics D0 game-development acceptance gate.
