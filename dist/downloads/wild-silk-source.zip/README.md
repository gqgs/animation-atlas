# Wild Silk source

Serve this folder with `python3 -m http.server 8080` and open http://localhost:8080. Keep experiments/ and shared/ together. See experiments/wild-silk/README.md.
